/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A44
 */

#ifndef xconfig_empty__
#define xconfig_empty__



#endif /* xconfig_empty__ */ 
