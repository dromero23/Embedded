/*
 * UARTComm.c
 *
 *  Created on: Dec 7, 2014
 *      Author: Chi-lun Chu and Daniel Romero
 */
//**header files**//
#include "Command.h"
#include "StateFunc.h"

//**define**//
#define MAX 25
#define BACKSPACE 8		//define to use backspace to allow editing of input
#define LISTSIZE 14     //used for the size of the list
//**extern values from Global header**//
extern UART_Handle uart;	//uart handle to allow output to the
extern int LightVal;
extern int LightVal2;
extern int LightVal3;
extern char CR;
extern char NL;
extern int distance;

//**static variables for Command.c**//
char checkSum;
char *gCommand;
int gCSize;
char myArray[45];
 int bufLength=50;
 char *ackBuffer;

 /*myList is the command list that we call
  * when there is correct command type which is the character array CMD[3]
  */
 const commandType myList[LISTSIZE]={
 	{2, "FW", &moveForward,"I have move forward.\n\r"},
 	{2, "T6", &testPin6,"Testing pin 6.\n\r"},
 	{2, "T7", &testPin7,"Testing pin7.\n\r"},
 	{2, "BK", &moveBackward, "Moving backward.\n"},
 	{2, "SN", &spinMe, "I am spinning!\n\r"},
 	{2, "LH", &leftTurn, "Turning Left.\n\r"},
 	{2, "RH", &rightTurn, "Turning Right.\n\r"},
 	{2, "RS", &readSensor, "Reading Sonar Values\n\r"},
 	{2, "SS", &stopSensor, "Stop reading sonar Values.\n\r"},
 	{2, "BR", &beginRace, "Begin race!\n\r"},
 	{2, "ER", &endRace,"Stop the race\n\r"},
 	{2, "RL", &readLight,"Reading light Values: \n\r"},
 	{2,"T5", &testPin5,"Testing pin 5.\n\r"},
 	{2,"T4", &testPin4,"Testing pin 4.\n\r"}
 };


 //**functions for myList**//

 /*-------moveForward------
  * Description: call the driveFunction to set the duty cycle to 50,50 and writes
  * into the appropiate pins to drive the motor.
  */
void moveForward(void){
	DriveForw(50,50);
}

/*-------testPin4------
 * Description: Test the motors/ test (GPIO PIN 4)
 */
void testPin4(void){
	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7), (GPIO_PIN_4)); //test pin 6 for motors)
}

/*-------testPin5------
 * Description: Test the motors/ test (GPIO PIN 5)
 */
void testPin5(void){
	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7), (GPIO_PIN_5)); //test pin 6 for motors)
}

/* -------testPin6------
 * Description: Test the motors/ test (GPIO PIN 6)
 */
void testPin6(void){
	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7), (GPIO_PIN_6)); //test pin 6 for motors
}

/* -------testPin7------
 * Description: Test the motors/ test (GPIO PIN 7)
 */
void testPin7(void){

	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7), (GPIO_PIN_7)); //test pin 7 for motors
}

/* -------moveBackward------
 * Description: call the driveFunction to set the duty cycle to 50,50 and writes
 * into the appropiate pins to drive the motor in the opposite way of the function
 * moveForward
 */
void moveBackward(void){
	//initialize necessary values for calculating PWM
	volatile uint32_t ui32Load;
	int Duty = 20;
	volatile uint32_t ui32PWMClock;
	int PWM_FREQUENCY = 50;

	ui32PWMClock = SysCtlClockGet()/64; // set up PWM clock frequency = 1.25 [Mhz]
	ui32Load = (ui32PWMClock / PWM_FREQUENCY) - 1; // Calculate Load counter (this determines PWM period)


	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7), (GPIO_PIN_4|GPIO_PIN_6));  //Set Motors to reverse
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_1, (Duty*ui32Load)/100); //Set up period with calculated Load value
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_0, (Duty*ui32Load)/100);
}

/* -------spinMe------
 * Description: Set the motors to rotate against each other in order to make the robot "spin"
 */
void spinMe(void){
	//Set up necessary values to calculate the PWM
	volatile uint32_t ui32Load;
	int Duty = 20;
	volatile uint32_t ui32PWMClock;
	int PWM_FREQUENCY = 50;

	ui32PWMClock = SysCtlClockGet()/64; // set up PWM clock frequency = 1.25 [Mhz]
	ui32Load = (ui32PWMClock / PWM_FREQUENCY) - 1; // Calculate Load counter (this determines PWM period)

	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7), (GPIO_PIN_4|GPIO_PIN_7));
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_1, (Duty*ui32Load)/100); //Set up period with calculated Load value
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_0, (Duty*ui32Load)/100);
}
//void HelpCommand(void){
//	int pos =0;
//	while(pos<LISTSIZE){
//		char cmd[2];
//		strncpy(cmd,myList[LISTSIZE].CMD,2);
//		UART_write(uart,cmd,2);
//		char separator[] = " | ";
//		char myMSG[100];
//		strncpy(myMSG,myList[LISTSIZE].message,sizeof(myList[LISTSIZE].message));
//		UART_write(uart, myMSG,sizeof(myList[LISTSIZE].message));
//		UART_write(uart,&CR,sizeof(CR));
//		pos++;
//	}
//}

/* -------leftTurn------
 * Description: call the driveFunction to set the duty cycle and writes to the appropiate pins
 * to have the robot turn left.
 */
void leftTurn(void){
	DriveForw(10,20);
}

/* -------rightTurn------
 * Description: call the driveFunction to set the duty cycle and writes to the appropiate pins
 * to have the robot turn right.
 */
void rightTurn(void){
	DriveForw(20,10);
}

/* -------readSensor------
 * Description: starts the reading from the Ultrasonic sensor (uses double buffer to output
 * to Terra Term)
 */
void readSensor(void){
	Clock_start(DataReadinit);
}

/* -------stopSensor------
 * Description: stops the reading from the Ultrasonic sensor
 */
void stopSensor(void){
	Clock_stop(DataReadinit);
}

/* -------beginRace------
 * Description: begins the course, starts the PID clock.
 */
void beginRace(void){
	StateFunStart();
}

/* -------endRace------
 * Description: ends the course, stops the PID clock and sets the Drive to 0,0
 */
void endRace(void){
	DriveForw(0,0);
	//this used to stop the motors from running
	GPIOPinTypeGPIOInput(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7));   //disable motors
}

/* -------readLight------
 * Description: reads the current light sensor values.
 */
void readLight(void){
	// check the global variables that contain the value of each of the light sensors
	//write user indicator to convey the meaning of the following binary numbers
	char valueIndication[] = "\n\rSensors\n\r123:\n\r";
	UART_write(uart,valueIndication,sizeof(valueIndication));
	char zero= '0';
	char one = '1';
	if(LightVal)
		UART_write(uart,&one,1);
	else
		UART_write(uart, &zero,1);
	if(LightVal2)
		UART_write(uart, &one,1);
	else
		UART_write(uart, &zero,1);
	if(LightVal3)
		UART_write(uart, &one,1);
	 else
		 UART_write(uart,&zero,1);

	UART_write(uart, &CR, sizeof(CR));  //move to the next line
	UART_write(uart,&NL, sizeof(NL));

}

//** end of the functions for myList**//

/*
 *  ======== RxCmd ========
 *  Task for this function is created statically. See the project's .cfg file.
 *  The substitute for the echoFxn
 *  Function Type: Task
 *  Semaphore Pends: CmdBufferMutex
 *  Semaphore Post: CmdBufferMutex & NewCmdSema
 */
Void RxCmd(UArg arg0, UArg arg1)
{
    const char echoPrompt[] = "\fEchoing characters:\r\n";

    if (uart == NULL) {
        System_abort("Error opening the UART");
    }

    UART_write(uart, echoPrompt, sizeof(echoPrompt));
    int tooMany;
    /* Loop forever echoing */
    while (1) {

    	const char tildi = '~';
    	char st;
    	UART_read(uart,&st,1);

    	//wait until the value being read is a tildi; otherwirse, loop forever
    	while(strncmp(st,tildi,1)){
    		UART_read(uart,&st,1);
    	}
    	UART_write(uart,&st,sizeof(st)); // meaning that you can type in a command
    	char frame[MAX]; //max is 100 for frame to hold incoming command data
   	    int frameLength=0;
   		readFrame(frame,MAX , &frameLength);

   		//move to next line to show response
   		UART_write(uart,&CR,1);
   		UART_write(uart, &NL,1);

   		//separate frame and command data
   		Semaphore_pend(CmdBufferMutex, BIOS_WAIT_FOREVER);
			tooMany = parseCommand(frame, frameLength); //breaks the frame into different pieces
		if(!tooMany){
		  Semaphore_post(NewCmdSema);   //indicate to frame that a new command has been read into the command buffer
		}
		else{
			const char invalid[] = "Too many arguments for any command!\n";
			UART_write(uart, &invalid, sizeof(invalid));
		}
		Semaphore_post(CmdBufferMutex);

    }
}


/*
 *  ======== TxAck ========
 *  Used for calling writeFrame using the bufLength (length of buffer) and the ackBuffer
 *  Function Type: Task
 *  Semaphore Pends: TxAckSema & TxMutex
 *  Semaphore Post:  TxMutex
 */
void TxAck (void){
	while(1){
		Semaphore_pend(TxAckSema,BIOS_WAIT_FOREVER);    //wait for acknowledge to be called
		Semaphore_pend(TxMutex, BIOS_WAIT_FOREVER);     //wait for transmit mutex to be free
			char ident[]="AK";
			writeframe(ackBuffer, bufLength, ident);    //write the correct acknowledge to the UART
		Semaphore_post(TxMutex);
	}
}

/*
 *  ======== CmdInt ========
 *  Used for interpret the users input and calls getCommand to identify the command
 *  after identify the command, the task calls the appropiate function and the message to be
 *  displayed using TxAck
 *  Function Type: Task
 *  Semaphore Pends: NewCmdSema & CmdBufferMutex
 *  Semaphore Post: TxAckSema & CmdBufferMutex
 */
void CmdInt (void){
	while(1){
	 Semaphore_pend(NewCmdSema,BIOS_WAIT_FOREVER);      //wait for a new command to be transmitted
	 Semaphore_pend(CmdBufferMutex,BIOS_WAIT_FOREVER);  //wait for command buffer to have accepted the new command
		int ackState;
		ackState= getCommand();  //return position of command

		//determine the acknowledge to return
		if(ackState<0){
			ackState =ackState *-1;
			char case1[]= "Too many arguments\r\n";
			char case2[]= "Not enough arguments\r\n";
			char case3[] = "Wrong Argument(s)\r\n";
			char case4[] = "Invalid Command\r\n";
			switch(ackState){
				case 1:
					bufLength = sizeof(case1);
					ackBuffer= case1;
					break;
				case 2:

					bufLength = sizeof(case2);
					ackBuffer=case2;
					break;
				case 3:
					bufLength = sizeof(case3);
					ackBuffer=case3;

					break;
				case 4:
					bufLength = sizeof(case4);
					ackBuffer=case4;
					break;
			}
		}
		else{

			if(checkSum== '0'){
				myList[ackState].myFunc();
				strncpy(myArray, (myList[ackState].message),45);
				bufLength = sizeof(myArray);
				ackBuffer=myArray;
			}
			else{
				char invCheck[]= "Invalid checksum\r\n";
				ackBuffer=invCheck;
				bufLength = sizeof(invCheck);
			}
		}
		Semaphore_post(TxAckSema);
		Semaphore_post(CmdBufferMutex);
	}
}




/*
 * -------readFrame------
 * Description: reads the user's input and the global buffer points to the beginning of the input[]
 * Inputs:
 *  -input[]: the array to place the user's input
 *  -size: the size of the array
 *  -length: the new filled size of the array
 */
//** the uart handle is what allows it to display on the screen **
void readFrame(  char input[], int size, int *length) {
	char tempInput;
	int tempLength=0;
	int bkFlag=0;
//	read the input from the serial port and echo it back
	UART_read(uart, &tempInput,1);
	UART_write(uart, &tempInput,1);

	//loop to read the full length of the buffer or until
	while( (tempInput !=0) && (tempInput!=13) ){

	    //if ascii character is a backspace, return to a previous cell
		if( (tempInput==BACKSPACE) && (tempLength>0)){
			tempLength--;
			bkFlag=1;
		}
		else if(tempLength>=size)
			break;
		else if( (tempInput!=BACKSPACE) )
			input[tempLength]=tempInput;
		else {
			//do nothing
		}
		UART_read(uart, &tempInput,1);
		UART_write(uart, &tempInput,1);
		if(!bkFlag)
			tempLength++;
		bkFlag=0;
  }
	*(length) =  *(length) + tempLength;
}

/* -------parseCommand------
 * Description: parses the frame[] and takes the cmd, *Argument 1 & 2 and returns an int value
 * whether it is a command that has too many arguments (for any command or not)
 *                   *(does not work for now)
 * Inputs:
 * 	-frame[]: the array that holds the users input
 * 	-frameLength: the filled content of the array
*   Output:
*   	- int value: returns true or false
 */
int parseCommand(char frame[], int frameLength){
	int pos=0;
	int stateBuff=0; //the state of the buffer;
	gCommand = frame; //gCommand is a char of 2 array;
	gCSize = 0;
	while(pos<frameLength){
			switch(stateBuff){
				case 0:
					if( (frame[pos]== 32) && ((pos+1)<frameLength-1) ){
						//gArg1= frame+pos+1;
						//stateBuff=1;
						stateBuff=3;
					}
					else if(frame[pos]=='0'){
						//do nothing
					}
					else{
						gCSize++;
						stateBuff = 0;
					}
					break;
				default:
					return 1;
			}
			pos++;
	}
	checkSum=frame[frameLength-1];
	return 0;
}

/*
 *  ======== getCommand ========
 *  checks the gXsize of each gParameter and determines if the function can be called or not
 *  returns the position of where to call the command.
 *  Function Type: Function
 *  Semaphore Pends: -
 *  Semaphore Post: -
 *  Output: int value: returns the position of the appropiate command to call;
 */
int getCommand(){
	//start from the beginning
	if (gCSize!=2){
		return -4; //wrong command
	}
	else{
		const char myCmd[2];
		strncpy(myCmd, gCommand, 2);
		int posList=0;
		int size = sizeof(myList);
		for(; posList< sizeof(myList); posList++){
			if(!strncmp(myCmd, (myList[posList].CMD),2))
				return posList;
		}
		return -4; //wrong command
	}
}
