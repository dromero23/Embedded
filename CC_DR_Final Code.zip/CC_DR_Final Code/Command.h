/*
 * Command.h
 *
 *  Created on: Dec 2, 2014
 *      Author: Chi-lun Chu and Daniel Romero
 */

#ifndef COMMAND_H_
#define COMMAND_H_
//**header file**//
#include "SerialComm.h"
#include "Sonar.h"
#include "StateFunc.h"
#include "SerialComm.h"
#include "PID.h"


//**struct**//
/*
 * the struct is used to place attributes on each command:
 * size: the size that the buffer should be *(optional for now)
 * CMD: the array that holds the command ex. "FW"
 * myFunc: calls the appropriate function for that command
 * message: The acknowledge message for outputting for a succesful command
 * hashCheckSum: checkSum for the appropriate buffer input
 */
const struct Command{
	int size;
	char CMD[3];
    void (*myFunc)(void);
    char message[100];};

typedef const struct Command commandType;
// ** functions **//
/*-------readFrame------
 * Description: reads the user's input and the global buffer points to the beginning of the input[]
 * Inputs:
 * 	-input[]: the array to place the user's input
 * 	-size: the size of the array
 * 	-length: the new filled size of the array
 */
void readFrame( char input[], int size, int *length);
/*-------parseCommand------
 * Description: parses the frame[] and takes the cmd, *Argument 1 & 2 and returns an int value
 * whether it is a command that has too many arguments (for any command or not)
 *                   *(does not work for now)
 * Inputs:
 * 	-frame[]: the array that holds the users input
 * 	-frameLength: the filled content of the array
*   Output:
*   	- int value: returns true or false
 */
int parseCommand(char frame[], int frameLength);

/*-------moveForward------
 * Description: call the driveFunction to set the duty cycle to 50,50 and writes
 * into the appropiate pins to drive the motor.
 */
void moveForward(void);
/*-------testPin4------
 * Description: Test the motors/ test (GPIO PIN 4)
 */
void testPin4(void);
/*-------testPin5------
 * Description: Test the motors/ test (GPIO PIN 5)
 */
void testPin5(void);
/*-------testPin6------
 * Description: Test the motors/ test (GPIO PIN 6)
 */
void testPin6(void);
/* -------testPin7------
 * Description: Test the motors/ test (GPIO PIN 7)
 */
void testPin7(void);
/* -------moveBackward------
 * Description: call the driveFunction to set the duty cycle to 50,50 and writes
 * into the appropiate pins to drive the motor in the opposite way of the function
 * moveForward
 */
void moveBackward(void);
/* -------spinMe------
 * Description: Set the motors to rotate against each other in order to make the robot "spin"
 */
void spinMe(void);
/* -------HelpCommand------
 * Description: Displays the myList table of acceptable commands
 * ***Has not been tested completely.
 */
void HelpCommand(void);
/* -------leftTurn------
 * Description: call the driveFunction to set the duty cycle and writes to the appropiate pins
 * to have the robot turn left.
 */
void leftTurn(void);
/* -------rightTurn------
 * Description: call the driveFunction to set the duty cycle and writes to the appropiate pins
 * to have the robot turn right.
 */
void rightTurn(void);
/* -------readSensor------
 * Description: starts the reading from the Ultrasonic sensor (uses double buffer to output
 * to Terra Term)
 */
void readSensor(void);
/* -------stopSensor------
 * Description: stops the reading from the Ultrasonic sensor
 */
void stopSensor(void);
/* -------beginRace------
 * Description: begins the course, starts the PID clock.
 */
void beginRace(void);
/* -------endRace------
 * Description: ends the course, stops the PID clock and sets the Drive to 0,0
 */
void endRace(void);
/* -------readLight------
 * Description: reads the current light sensor values.
 */
void readLight(void);

#endif /* COMMAND_H_ */
