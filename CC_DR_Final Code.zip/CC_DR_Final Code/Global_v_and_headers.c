/*
 * Global_v_and_headers.c
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel Romero and Chi-lun Chu
 */
#include "Global_v_and_headers.h"
//initialize variables to read the light sensor
int32_t LightVal;//left
int32_t LightVal2;//center
int32_t LightVal3;//right

//initialize UART destination for use by multiple functions
UART_Handle uart;

//initialize variables for PID calculation of error
signed int e[4];

//variable to hold the distance value
int distance = 0;

//transmission buffers
char *bufPoint;		//pointer to buffer for storing values
char *bufTrans;		//pointer to buffer for transmitting values
//initialize carriage return for reference
const char CR = 13; //carriage return
const char NL = 10; //new line
// State variables
int stateRob;

