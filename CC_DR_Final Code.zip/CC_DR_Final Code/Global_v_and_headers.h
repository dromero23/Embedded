/*
 * Global_v_and_headers.h
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */

#ifndef GLOBAL_V_AND_HEADERS_H_
#define GLOBAL_V_AND_HEADERS_H_

/* XDCtools Header files */
#include <xdc/std.h>
#include <xdc/cfg/global.h>
#include <xdc/runtime/System.h>
#include <xdc/runtime/Log.h>
//#include <ti/sysbios/Hwi.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/UART.h>
#include <ti\sysbios\hal\Timer.h>
//#include <ti/drivers/UART.c>

/* Example/Board Header files */
#include "Board.h"
#include <stdint.h>
#include <stdbool.h>
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/interrupt.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "inc/hw_timer.h"
#include <string.h>
#include "inc/hw_types.h"
#include "inc/hw_gpio.h"
#include "driverlib/pwm.h"
#include "driverlib/debug.h"
#include <ti\sysbios\knl\Semaphore.h>
#include <ti\sysbios\knl\Swi.h>
#include <ti\sysbios\knl\Clock.h>
#include <ti\sysbios\knl\Task.h>



#endif /* GLOBAL_V_AND_HEADERS_H_ */
