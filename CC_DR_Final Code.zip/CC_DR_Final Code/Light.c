/*
 * Light.c
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */


/*
 *
 *
 * Light Sensor Functions
 *
 */
#include "Light.h"
extern int LightVal;
extern int LightVal2;
extern int LightVal3;


//-------------------------checkLightTurnOff--------------------------
// Interrupts after 15 microseconds using timer3 and sets to read light sensors but starts timer2 to wait 300 microseconds first
// Input: timer2 handle, timer3 handle
// Output: none
void checkLightTurnOff(void)
{
	Timer_stop(timer3);
		//Set pints to input to stop charging the light sensor
		GPIOPinTypeGPIOInput(GPIO_PORTB_BASE, (GPIO_PIN_2));
		GPIOPinTypeGPIOInput(GPIO_PORTE_BASE, (GPIO_PIN_0));
		GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, (GPIO_PIN_0));

		//reset the timer2 for the checkLightTurnOn function
		Timer_start(timer2);
		TimerIntClear(TIMER2_BASE, TIMER_BOTH);
		TimerEnable(TIMER2_BASE, TIMER_BOTH);

}


//-------------------------checkLightTurnOn--------------------------
// Interrupts after 300 microseconds using timer2 and retreives the light values
// Input: 	SensorSema to indicate that the value was read
// Output: 	none
void checkLightTurnOn(void)
{
	Timer_stop(timer2);
	//get values from the pins for the light sensor
	LightVal = GPIOPinRead(GPIO_PORTB_BASE, (GPIO_PIN_2));
	LightVal2= GPIOPinRead(GPIO_PORTE_BASE, (GPIO_PIN_0));
	LightVal3= GPIOPinRead(GPIO_PORTF_BASE, (GPIO_PIN_0));



	Semaphore_post(SensorSema);  //tell the program that it has retreived the light data
}

/* ======== lightSensorInit ========
 * description: Configuration for the light sensor
 * and set the necessary pins for the light sensor
 */
void lightSensorInit(void){
	  //Set output to Light Sensor
	   GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, (GPIO_PIN_2)); //PB2, PE0, PF0 are configured to power output
	   GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, (GPIO_PIN_0)); //PB2, PE0, PF0 are configured to power output
	   GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, (GPIO_PIN_0)); //PB2, PE0, PF0 are configured to power output
	   GPIOPinWrite(GPIO_PORTB_BASE, (GPIO_PIN_2), (GPIO_PIN_2)); //Charge up light sensor output
	   GPIOPinWrite(GPIO_PORTE_BASE, (GPIO_PIN_0), (GPIO_PIN_0)); //Charge up light sensor output
	   GPIOPinWrite(GPIO_PORTF_BASE, (GPIO_PIN_0), (GPIO_PIN_0)); //Charge up light sensor output
}
