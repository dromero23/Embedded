/*
 * Light.h
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */

#ifndef LIGHT_H_
#define LIGHT_H_
#include "Global_v_and_headers.h"


/*
 *  ======== Light Sensor functions ========
 *  Description: Create functions to retreive the current light values of black or white *
 *
 */
/* ======== lightSensorInit ========
 * description: Configuration for the light sensor
 * and set the necessary pins for the light sensor
 */
void lightSensorInit(void);

//-------------------------checkLightTurnOff--------------------------
// Interrupts after 15 microseconds using timer3 and sets to read light sensors but starts timer2 to wait 300 microseconds first
// Input: timer2 handle, timer3 handle
// Output: none
void checkLightTurnOff(void);

//-------------------------checkLightTurnOn--------------------------
// Interrupts after 300 microseconds using timer2 and retreives the light values
// Input: 	SensorSema to indicate that the value was read
// Output: 	none
void checkLightTurnOn(void);

#endif /* LIGHT_H_ */
