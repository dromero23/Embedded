/*
 * PID.c
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */

#include "PID.h"
#include "StateFunc.h"
#include "SerialComm.h"
#include "Global_v_and_headers.h"
//variables to contain the light values
extern int LightVal;
extern int LightVal2;
extern int LightVal3;
extern int stateRob;

extern signed int e[4];
static int P[2] = {0,0};
static int I[2] = {0,0};
static int D[2] = {0,0};
const int Kp=3;
const int Ki=7;
const int Kd=45;
static int errorCount=0;
static int countBla = 0;


/*
 *  ======== drive functions ========
 *  Description: Create functions to drive the wheels
 *
 *
 */
/* ======== motorInit =======
 * description: Initialize the pwm set up for the motors
 * input: none
 * output: none
 */
void motorInit(void){
	//PWM set up
		//initialize the necessary variables for motor function
		volatile uint32_t ui32PWMClock;
		int PWM_FREQUENCY = 50;
		volatile uint32_t ui32Load;
		volatile uint8_t ui8Adjust;
		ui8Adjust = 83;
		int Duty = 0;
	    SysCtlPWMClockSet(SYSCTL_PWMDIV_64); //PWM clock at the modules is 80[Mhz]/4
	    ui32PWMClock = SysCtlClockGet()/64; // set up PWM clock frequency = 1.25 [Mhz]
	    ui32Load = (ui32PWMClock / PWM_FREQUENCY) - 1; // Calculate Load counter (this determines PWM period)
	    //Another way to set up Load is: Load=PWMperiod/Sytemclockperiod;

	    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1); // enable PWM module 1

	    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD); //Enable port D to use for the PWM

	    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC); //Enable port C to use for the control of the Motors

	    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);	//Enable port B to use for reading the light sensor
	    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);	//Enable port E to use for reading the light sensor
	    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);	//Enable port F to use for reading the light sensor

	    //configure PWM ports and pins
	    GPIOPinTypePWM(GPIO_PORTD_BASE, GPIO_PIN_0);
	    GPIOPinTypePWM(GPIO_PORTD_BASE, GPIO_PIN_1);

	    GPIOPinConfigure(GPIO_PD1_M1PWM1); //PD1 will be controlled by PWM1 (module 1, generator 0)
	    GPIOPinConfigure(GPIO_PD0_M1PWM0); //PD0 will be controlled by PWM0 (module 1, generator 0)
	    GPIOPinTypeGPIOOutput(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7));  //PC4 PC5 PC6 PC7 are configured to output a value




	    PWMGenConfigure(PWM1_BASE, PWM_GEN_0, PWM_GEN_MODE_DOWN); // Set up Generator 3 as Count down mode
	    PWMGenPeriodSet(PWM1_BASE, PWM_GEN_0, ui32Load); //Set up period with calculated Load value


	    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_1, (Duty*ui32Load)/100); 	//Set up period with calculated Load value
	    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_0, (Duty*ui32Load)/100);	//Set up period with calculated Load value

	    PWMOutputState(PWM1_BASE, PWM_OUT_1_BIT, true); //Turn output on (like opening a gate)
	    PWMOutputState(PWM1_BASE, PWM_OUT_0_BIT, true); //Turn output on (like opening a gate)
	    PWMGenEnable(PWM1_BASE, PWM_GEN_0);


}
//-------------------------u--------------------------
//PID calculation function to determine how much to vary the duty cycle
// Input: 	LightVal, LightVal2, LightVal3,
//			e[4], Kp, Ki, Kd,
//			P[2], I[2], D[2]
// Output: val: amount of error to change the duty cycle
int u(void){
	//left side
	//save previous error values
	e[3]=e[2];
	e[2]=e[1];
	e[1]=e[0];
	//check light values and set error according to the values of the three dots
	switch (LightVal){

	case 4:
		//right side
		switch (LightVal3){
			case 1:
				//center
				switch(LightVal2){
					default:
						e[0]=0; //no error
						break;
				}
				break;
			case 0:
				//center
				switch(LightVal2){
				case 1:
					e[0]=1;
					break;
				case 0:
					e[0]=3;
					break;
			}
			break;
		}
		break;
	case 0:
	//right side
		switch (LightVal3){
			case 1:
				//center
				switch(LightVal2){
					case 1:
						e[0]=-1;
						break;
					case 0:
						e[0]=-3;
						break;
				}
				break;
			case 0:
				//center
				switch(LightVal2){
				case 1:
					e[0]=0;
					break;
				case 0:
					if(e[1]<0)
						e[0]=-5;
					else if(e[1]>0)
						e[0]=5;
					else
						e[0]= 0;
					break;
			}
			break;
		}
		break;

	}

	//calculate the overshoot
	D[1]=D[0];
	if(errorCount<4){
		D[0]=(e[0]+e[1])/2;
		errorCount++;
	}
	else{
		D[0]=Kd*(e[0]+3*e[1]-3*e[2]-e[3]);
		D[0]=D[0]/6;
	}

	//calculate steady state error
	I[1]=I[0];
	I[0]=I[1]+(Ki*e[0])/100;

	//calculate direct error
	P[1]=P[0];
	P[0]=Kp*e[0];

	int val = (P[0]+I[0]+D[0]);
	return val;
}

//-------------------------DriveForw--------------------------
// Drive motors forward at variable duty
// Input: duty1 and duty2: used to apply a duty cycle to the motors
// Output: none
void DriveForw(int Left, int Right){

	volatile uint32_t ui32Load;
	volatile uint32_t ui32PWMClock;
	int PWM_FREQUENCY = 50;

	ui32PWMClock = SysCtlClockGet()/64; // set up PWM clock frequency = 1.25 [Mhz]
	ui32Load = (ui32PWMClock / PWM_FREQUENCY) - 1; // Calculate Load counter (this determines PWM period)

	GPIOPinWrite(GPIO_PORTC_BASE, (GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7), (GPIO_PIN_5|GPIO_PIN_7)); //Set motors to forward
	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_1, (Left*ui32Load)/100); //Set up period with calculated Load value

	PWMPulseWidthSet(PWM1_BASE, PWM_OUT_0, (Right*ui32Load)/100); //Set another duty cycle for the other motor
}

//-------------------------folLine--------------------------
//Take the light values and alter the duty cycle by the determined amount
// Input: none
// Output: none
void folLine(void){
	//Set up necessary values to calculate the PWM
	volatile uint32_t ui32Load;
	int error = u();

	//calculate amount of duty cycle
	int Left = 25+error;
	int Right = 25-error;

	//limit values that can be applied
	if(Left<5)
		Left=5;
	else if(Left>50)
		Left=50;

	if(Right<5)
		Right=5;
	else if(Right>50)
		Right=50;

	DriveForw(Left, Right);
}

//-------------------------ReardSensors--------------------------
// Sets the process necessary to receive the light sensor values
// Input: none
// Output: none
void ReadSensorsW(void){
	//Start charging
	GPIOPinTypeGPIOOutput(GPIO_PORTB_BASE, (GPIO_PIN_2)); //PB2, PE0, PF0 are configured to power output
	GPIOPinTypeGPIOOutput(GPIO_PORTE_BASE, (GPIO_PIN_0)); //PB2, PE0, PF0 are configured to power output
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, (GPIO_PIN_0)); //PB2, PE0, PF0 are configured to power output
	GPIOPinWrite(GPIO_PORTB_BASE, (GPIO_PIN_2), (GPIO_PIN_2)); //Charge up light sensor output
	GPIOPinWrite(GPIO_PORTE_BASE, (GPIO_PIN_0), (GPIO_PIN_0)); //Charge up light sensor output
	GPIOPinWrite(GPIO_PORTF_BASE, (GPIO_PIN_0), (GPIO_PIN_0)); //Charge up light sensor output
	Timer_start(timer3);	//starts the timer to stop charging sensor in checkLightTurnOff
	TimerIntClear(TIMER3_BASE, TIMER_BOTH);
	TimerEnable(TIMER3_BASE, TIMER_BOTH);


	Semaphore_pend(SensorSema, BIOS_WAIT_FOREVER);  //waits for light sensor values to be read before exiting
}

//-------------------------DriveClockFun--------------------------
// HWI to set the Drive semaphore to drive the motors; Called by PIDClock every 10 milliseconds
// Input:	none
// Output:	none
void DriveClockFun(void){
	Semaphore_post(DriveSema);
	TimerIntClear(TIMER0_BASE, TIMER_BOTH);
}

//-------------------------DriveTsk--------------------------
// The drive task to set the sequence to receive light sensor values and drive the motors
// Input: none
// Output: none
void DriveTsk(void){
	for(;;){
		Semaphore_pend(DriveSema, BIOS_WAIT_FOREVER);	//wait 10 milliseconds to change the motors
		ReadSensorsW();	//sets the routine for retreiving the light values and storing them in the global light variables
		folLine();		//sets the routine for using the global light values to calculate and change the duty cycle to the wheels
		//Determine if driving over black line
		if(LightVal*LightVal2*LightVal3){
			countBla++;	//record width of black line detected
			//transition to next state in obsticle state function StateTsk
			if(countBla > 10){
				stateRob++;
				Semaphore_post(StateSema);
				countBla = 0;
			}
		}else if(countBla){
			countBla = 0;	//if black line was not detected reset counter to nullify false values
		}
	}
}




