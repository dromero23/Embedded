/*
 * PID.h
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */

#ifndef PID_H_
#define PID_H_
#include "Global_v_and_headers.h"


/*
 *  ======== drive functions ========
 *  Description: Create functions to drive the wheels
 *
 *
 */

/* ======== motorInit =======
 * description: Initialize the pwm set up for the motors
 * input: none
 * output: none
 */
void motorInit(void);

//-------------------------u--------------------------
//PID calculation function to determine how much to vary the duty cycle
// Input: 	LightVal, LightVal2, LightVal3,
//			e[4], Kp, Ki, Kd,
//			P[2], I[2], D[2]
// Output: val: amount of error to change the duty cycle
int u(void);

//-------------------------DriveForw--------------------------
// Drive motors forward at variable duty
// Input: duty1 and duty2: used to apply a duty cycle to the motors
// Output: none
void DriveForw(int Left, int Right);

//-------------------------folLine--------------------------
//Take the light values and alter the duty cycle by the determined amount
// Input: none
// Output: none
void folLine(void);

//-------------------------ReardSensors--------------------------
// Sets the process necessary to receive the light sensor values
// Input: none
// Output: none
void ReadSensorsW(void);

//-------------------------DriveClockFun--------------------------
// HWI to set the Drive semaphore to drive the motors; Called by PIDClock every 10 milliseconds
// Input:	none
// Output:	none
void DriveClockFun(void);

//-------------------------DriveTsk--------------------------
// The drive task to set the sequence to receive light sensor values and drive the motors
// Input: none
// Output: none
void DriveTsk(void);

#endif /* PID_H_ */
