/*
 * SerialComm.c
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */
#include "SerialComm.h"
#include "Global_v_and_headers.h"
extern int countzero;
extern UART_Handle uart;
extern char CR;
extern char NL;
UART_Params uartParams;

/*
 *  ======== UARTInit ========
 *  Description: Initialization for using UART serial communication.
 *  Input: None
 *  Output: None
 *
 */
void UARTInit(void){
       /* Create a UART with data processing off. */
        UART_Params_init(&uartParams);
        uartParams.writeDataMode = UART_DATA_BINARY;
        uartParams.readDataMode = UART_DATA_BINARY;
        uartParams.readReturnMode = UART_RETURN_FULL;
        uartParams.readEcho = UART_ECHO_OFF;
        uartParams.baudRate = 9600;
        uart = UART_open(Board_UART1, &uartParams);

}


//
//-------------------------writeframe--------------------------
// writes out the collected data in ascii form to the bluetooth
// Input: data: the buffer that holds the data to be transmitted
//        len: the length of the buffer passed to the function
//        ident: the identifier to add to the frame to indicate the type of data being transmitted
// Output: none
void writeframe(char *data, const int len, const char *ident){

    const char initframe[] ="$";    //frame to show where the next data starts

    UART_write(uart,initframe,sizeof(initframe));   //output indicator of start of frame for data
    UART_write(uart,ident, 2);      //output data identifier to indicate the type of data transmitted
    UART_write(uart, &CR, sizeof(CR));  //output checksum as part of frame to separate data points
    UART_write(uart, &NL, sizeof(NL));  //output new line as part of frame to separate data points
    UART_write(uart,data, len);         //output data

}



/*
 *  ======== DecimalToAscii ========
 *  Description: Converts int numbers to ascii and display on Terra Term
 *  Used to transmit the distance data in ascii characters
 *  Input: uart is the uart where the user wants to display at and n is the number
 *  	   that we want to display on Terra term
 *  Output: None
 *  	Ex. int 12 is displayed as '1'2'
 *
 */
void DecimaltoAscii(UART_Handle uart, int n){
	int negFlag=0;
	char error;

	if(n<0){
		negFlag = 1;
		n=n*-1;
	}
	if(n>=10){
		countzero--;
		DecimaltoAscii(uart, n/10);
		n=n%10;
	}
	error = n+ '0';
	if(negFlag){
			char dash = '-';
			UART_write(uart,&dash,sizeof(dash));
	}
	char extra1 ='0';
	if(countzero>=0){
		while((countzero)){

			UART_write(uart, &extra1, sizeof(extra1));
			countzero--;
		}
	}
	UART_write(uart, &error, sizeof(error));

}



/*
 *  ======== DecimalToAscii2 ========
 *  Description: Converts int numbers to ascii and display on Terra Term
 *  Used to transmit the distance data in ascii characters
 *  Input: buf: stores the calculated ascii values
 *  		n: the integer that needs to be converted
 *  		len: the length of the ascii string to be calculated
 *  Output: None
 *  	Ex. int 12 is displayed as '1'2'
 *
 */
void DecimaltoAscii2(char *buf, int n, int len){

	//recursively divide by 10's until reaching one's place
	if(n>=10){
		DecimaltoAscii2(buf, n/10, len-1);
		n=n%10;
	}
	//Keep data store to buffer at a constant length by storing zeroes recursively first if needed
	else if(len>0){
		DecimaltoAscii2(buf, 0,len-1);
	}
	//change the one's place value to an ascii value
	*(buf+len)= n +'0';
}





/*
 *  ======== AsciiToDecimal ========
 *  Description: Converts the ascii numbers to integer values
 *  Input: pointer to a character of numbers, and the size of characters being read
 *  Output: The integer representation of the characters being read
 *  	Ex. characters '1''2' are converter into int 12
 *
 */
int AsciiToDecimal( char *length, int size){
	int decimal=0;
	int i =0;
	for(; i<size; i++){
		decimal =(decimal*10)+(length[i]-48); //decimal 48 is ascii character '0'
	}
	return decimal;
}


