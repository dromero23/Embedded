/*
 * SerialComm.h
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */

#ifndef SERIALCOMM_H_
#define SERIALCOMM_H_
#include "Global_v_and_headers.h"

/*
 * -------UARTInit------
 * Initializes the appropriate UART to read and write.
 */
void UARTInit(void);


//
//-------------------------writeframe--------------------------
// writes out the collected data in ascii form to the bluetooth
// Input: data: the buffer that holds the data to be transmitted
//        len: the length of the buffer passed to the function
//        ident: the identifier to add to the frame to indicate the type of data being transmitted
// Output: none
void writeframe(char *data, const int len, const char *ident);



/*
 *  ======== DecimalToAscii ========
 *  Description: Converts int numbers to ascii and display on Terra Term
 *  Used to transmit the distance data in ascii characters
 *  Input: uart is the uart where the user wants to display at and n is the number
 *  	   that we want to display on Terra term
 *  Output: None
 *  	Ex. int 12 is displayed as '1'2'
 *
 */

void DecimaltoAscii(UART_Handle uart, int n);


/*
 *  ======== DecimalToAscii2 ========
 *  Description: Converts int numbers to ascii and display on Terra Term
 *  Used to transmit the distance data in ascii characters
 *  Input: buf: stores the calculated ascii values
 *  		n: the integer that needs to be converted
 *  		len: the length of the ascii string to be calculated
 *  Output: None
 *  	Ex. int 12 is displayed as '1'2'
 *
 */
void DecimaltoAscii2(char *buf, int n, int len);



/*
 *  ======== AsciiToDecimal ========
 *  Description: Converts the ascii numbers to integer values
 *  Input: pointer to a character of numbers, and the size of characters being read
 *  Output: The integer representation of the characters being read
 *  	Ex. characters '1''2' are converter into int 12
 *
 */



int AsciiToDecimal( char *length, int size);


#endif /* SERIALCOMM_H_ */
