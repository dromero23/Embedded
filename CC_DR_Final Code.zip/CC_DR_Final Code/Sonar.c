/*
 * Sonar.c
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */
#include "Global_v_and_headers.h"
#include"Sonar.h"
#include"SerialComm.h"


extern char *bufPoint;
extern char *bufTrans;
extern int distance;
static int stateCal=0;
static int count=0;
static int eventA=0;
extern char CR;
extern char NL;
extern UART_Handle uart;


/*
 *  ======== InitUS ========
 *  Description: Initialization for using Ultrasonic Sensor.
 *  Input: None
 *  Output: None
 *
 */
void InitUS(void){
//    initialize the input capture to determine the distance
	SysCtlPeripheralEnable(SYSCTL_PERIPH_WTIMER5);
	TimerConfigure(WTIMER5_BASE,(TIMER_CFG_SPLIT_PAIR|TIMER_CFG_A_CAP_TIME));
	TimerClockSourceSet(WTIMER5_BASE, TIMER_CLOCK_SYSTEM);
	//TimerPrescaleSet(WTIMER5_BASE, TIMER_A, 2); User may prescale, however we will not be prescaling
	//our clocks
	TimerControlEvent(WTIMER5_BASE,TIMER_A, TIMER_EVENT_BOTH_EDGES);
	//sysctlenable is good because it is already set in main
	GPIOPinTypeGPIOInput(GPIO_PORTD_BASE, (GPIO_PIN_6));
	GPIOPinConfigure(GPIO_PD6_WT5CCP0);
	GPIOPinTypeTimer(GPIO_PORTD_BASE, (GPIO_PIN_6)); //ECHO Input
	GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, (GPIO_PIN_4));  //set pin to output trigger pulse


}


/*
 *  ======== transmit data ========
 *  Description: Transmit the buffer as soon as it is ready.
 *
 *
 *  Input: None
 *
 *  Output: None
 */





//-------------------------TransDataTsk--------------------------
// Task DataTsk which controls the transmission of data
// Input: bufTran: pointer to buffer to transmit data
// Output: none
void TransDataTsk(void){
	const char ident[] = "DT";
	const int Buflen = 100;
	for(;;){
			Semaphore_pend(TransSema, BIOS_WAIT_FOREVER);	//Wait for buffer to be ready for transmission
			Semaphore_pend(TxMutex, BIOS_WAIT_FOREVER);		//Wait for Mutex to be free to use. We have not implimented this in the command interpreter yet.
			writeframe(bufTrans, Buflen, ident);		//write the data to the bluetooth
			Semaphore_post(TxMutex);	//Free the mutex at the end of every data write
		}

}

/*
 *  ======== DataInitSema ========
 *  Description: Every 100ms start the process to retreive distance data using DataReadInit timer
 *                  HWI timer using DataReadinit timer
 *  Input: DataSema: used to initiate AcquireData task
 *
 *  Output: None
 */
void DataInitSema(void){
	Semaphore_post(DataSema);
	TimerIntClear(TIMER0_BASE, TIMER_BOTH);
}

/*
 *  ======== AcquireData ========
 *  Description: Sends a 10[us] pulse to the Ultrasonic
 *  			 The output pin for ultrasonic goes high and for the next occurent event happens
 *  			 every WTime5 [seconds]
 *  Input: bufPoint: global pointer to the buffer to store values
 *          bufTrans: global pointer to the buffer to transmit values
 *
 *  Output: None
 */
void AcquireData(void){
	const int Buflen = 100; //define the length of the buffer
	char buffer1[100];      //define buffer to hold distance values
	char buffer2[100];      //define buffer to hold distance values
	char bufAscii[3];       //define buffer to temporarily hold the calculated ascii values of the distance
	bufPoint = buffer1;     //set the initial buffer to store values to buffer1
	for(;;){
		Semaphore_pend(DataSema, BIOS_WAIT_FOREVER);        //wait 100ms for DataInitSema to post sema
		GPIOPinWrite(GPIO_PORTF_BASE, (GPIO_PIN_4), (GPIO_PIN_4)); //set high trigger
		Timer_start(PulseOff);  //start timer to turn trigger off after 10ms
		Semaphore_pend(DataSema,BIOS_WAIT_FOREVER);

		//start input capture to detect echo pulse
		TimerIntEnable(WTIMER5_BASE, TIMER_CAPA_EVENT);		// enables WTIMER5 input capture
		TimerEnable(WTIMER5_BASE, TIMER_A);
		TimerIntClear(WTIMER5_BASE, TIMER_CAPA_EVENT);
		Semaphore_pend(DataSema, BIOS_WAIT_FOREVER);

		//cap max distance detected to 2 feet or 610 mm
		if(distance>610){
			distance = 610;
		}

		//transform detected value to ascii to be discernable by textual receiver in computer
		DecimaltoAscii2(bufAscii, distance, sizeof(bufAscii)-1);

		//store distance ascii data in global buffer
		bufPoint[count++] = bufAscii[0];
		bufPoint[count++] = bufAscii[1];
		bufPoint[count++] = bufAscii[2];
		bufPoint[count++] = CR;
		bufPoint[count]=NL;

		//fill up 100 cells for each buffer before switching to the next buffer
		if(count>Buflen){
			count=0;
			if(bufPoint==buffer1){
				bufPoint = buffer2;
				bufTrans = buffer1;
			}
			else{
				bufPoint = buffer1;
				bufTrans = buffer2;
			}
			Semaphore_post(TransSema);				//tell the program that the buffer is ready for transmitting
		}
		else{
			count++;		//move to next cell to be filled with data in buffer
		}
	}
}

/*
 *  ======== SetLow ========
 *  Description: Sets trigger Pin for sonar sensor Low
 *  Input: None
 *
 *  Output: None
 */
void SetLow(void){
	GPIOPinWrite(GPIO_PORTF_BASE, (GPIO_PIN_4), 0); //set low
	Timer_stop(PulseOff);
	Semaphore_post(DataSema);
}
/*
 *  ======== PosEdge ========
 *  Description: Captures the posedge time of the timer.
 *  Input: None
 *
 *  Output: None
 */
void PosEdge(void){
	eventA = TimerValueGet(WTIMER5_BASE,TIMER_A);
}
/*
 *  ======== NegEdge ========
 *  Description: Captures the negedge time of the timer and calculates the difference
 *  Input: eventA: the global variable holding the value of the positive edge
 *
 *  Output: value of time difference between the positive edge and the negative edge
 */
int NegEdge(void){
	 return abs(TimerValueGet(WTIMER5_BASE,TIMER_A)-eventA);
}

/*
 *  ======== ReadSensor ========
 *  Description: Clears the interrupt for either positive or negative edge
 *  			Calls either PosEdge() or NegEdge() to capture and calculate the difference
 *  			time and stateCal switches when it captures the other different.
 *  Input: stateCal: the global variable holding the value of the phase in which the code should execute
 *
 *  Output: None
 *  Type: Interrupt (Pos Edge and Neg Edge Capture Event) Uses the ReadSonar HWI and WTimer5
 */
void ReadDistanceW(void){

		switch(stateCal){
			case 0:
//				UART_write(uart,notSuccess1,sizeof(notSuccess1));
				PosEdge();
				stateCal=1;
				TimerIntClear(WTIMER5_BASE, TIMER_CAPA_EVENT);			// must clear timer flag FROM timer

				break;
			case 1:
				distance = ((NegEdge()*10)/(58*80));		//use the time difference to calculate the distance.
				TimerIntClear(WTIMER5_BASE, TIMER_CAPA_EVENT);			// must clear timer flag FROM timer
				TimerDisable(WTIMER5_BASE, TIMER_A);
				stateCal = 0;
				Semaphore_post(DataSema);
				break;
		}
}


