/*
 * Sonar.h
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */

#ifndef SONAR_H_
#define SONAR_H_

#include"Global_v_and_headers.h"

/*
 *  ======== InitUS ========
 *  Description: Initialization for using Ultrasonic Sensor.
 *  Input: None
 *  Output: None
 *
 */
void InitUS(void);


/*
 *  ======== transmit data ========
 *  Description: Transmit the buffer as soon as it is ready.
 *
 *
 *  Input: None
 *
 *  Output: None
 */





//-------------------------TransDataTsk--------------------------
// Task DataTsk which controls the transmission of data
// Input: bufTran: pointer to buffer to transmit data
// Output: none
void TransDataTsk(void);

/*
 *  ======== DataInitSema ========
 *  Description: Every 100ms start the process to retreive distance data using DataReadInit timer
 *                  HWI timer using DataReadinit timer
 *  Input: DataSema: used to initiate AcquireData task
 *
 *  Output: None
 */
void DataInitSema(void);

/*
 *  ======== AcquireData ========
 *  Description: Sends a 10[us] pulse to the Ultrasonic
 *               The output pin for ultrasonic goes high and for the next occurent event happens
 *               every WTime5 [seconds]
 *  Input: bufPoint: global pointer to the buffer to store values
 *          bufTrans: global pointer to the buffer to transmit values
 *
 *  Output: None
 */
void AcquireData(void);

/*
 *  ======== SetLow ========
 *  Description: Sets trigger Pin for sonar sensor Low
 *  Input: None
 *
 *  Output: None
 */
void SetLow(void);
/*
 *  ======== PosEdge ========
 *  Description: Captures the posedge time of the timer.
 *  Input: None
 *
 *  Output: None
 */
void PosEdge(void);
/*
 *  ======== NegEdge ========
 *  Description: Captures the negedge time of the timer and calculates the difference
 *  Input: eventA: the global variable holding the value of the positive edge
 *
 *  Output: value of time difference between the positive edge and the negative edge
 */
int NegEdge(void);

/*
 *  ======== ReadSensor ========
 *  Description: Clears the interrupt for either positive or negative edge
 *              Calls either PosEdge() or NegEdge() to capture and calculate the difference
 *              time and stateCal switches when it captures the other different.
 *  Input: stateCal: the global variable holding the value of the phase in which the code should execute
 *
 *  Output: None
 *  Type: Interrupt (Pos Edge and Neg Edge Capture Event) Uses the ReadSonar HWI and WTimer5
 */
void ReadDistanceW(void);


#endif /* SONAR_H_ */
