/*
 * StateFunc.c
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */

#include "StateFunc.h"
#include "PID.h"
#include "Global_v_and_headers.h"
#include "SerialComm.h"
#include "Command.h"
extern int stateRob;
static int startDrive = 0;
static int stopDrive = 0;
extern UART_Handle uart;


//-------------------------InitState--------------------------
// Decides the current configuration of timers for the obsticle course
// Input: none
// Output: none
void InitState(void){
        //initialize the timer to stop the clock
		uint32_t ui32Period;
		SysCtlPeripheralEnable(SYSCTL_PERIPH_WTIMER3);
		TimerConfigure(WTIMER3_BASE, TIMER_CFG_PERIODIC);		// cfg WTimer 3 mode - periodic
        ui32Period = (SysCtlClockGet()/2);						// period = CPU clk div 2 (500ms)
		TimerLoadSet(WTIMER3_BASE, TIMER_A, ui32Period);			// set WTimer 3 period
		TimerIntEnable(WTIMER3_BASE, TIMER_TIMA_TIMEOUT);		// enables WTimer 3 to interrupt CPU
}

//-------------------------StateFunStart--------------------------
// Sets off the process of the states needed for the obsticle course
// Input: StateSema: sets to run the state
//        stateRob: decides the current state
// Output: none
void StateFunStart(void){
	Semaphore_post(StateSema);
	stateRob = 0;       //sets to state 0
}


//-------------------------StateTsk--------------------------
// Decides the current configuration in the obsticle course
// Input: StateSema: pauses the task to run other programs
//        stateRob: decides the current state to run
// Output: none
void StateTsk(void){
	const char PIDindicator[] ="PIDTimer \n\r";
	const char DataColindicator[] ="Data Collect\n\r";
	const char DataStopindicator[] ="Data Stop \n\r";
	for(;;){
		Semaphore_pend(StateSema, BIOS_WAIT_FOREVER);	//pause until next state is called

		switch(stateRob){
			case 0:
			    //initialize start up state
				Clock_start(StartUpClock);
				stateRob = 1;
				break;
			case 1:
			    //loop in start up state until motors are brought up to speed
				StartTsk();
				break;
			case 2:
			    //stop start up state and start line follow routine
				UART_write(uart,PIDindicator,sizeof(PIDindicator)); //indicate PID state
				Clock_stop(StartUpClock);
				Clock_start(PIDClock);
				break;
			case 3:
			    //start data collect state
				UART_write(uart,DataColindicator,sizeof(DataColindicator));
				Clock_start(DataReadinit);
				break;
			case 4:
//			    stop data collect state
			    UART_write(uart,DataStopindicator,sizeof(DataStopindicator));
				Clock_stop(DataReadinit);
				break;
			case 5:
//			    stop PID state
				Clock_stop(PIDClock);

				//start timer to loop to slow down
				TimerIntClear(WTIMER3_BASE, TIMER_A);
				TimerEnable(WTIMER3_BASE, TIMER_A);						// enable Timer 2
				break;
			case 6:
			    //loop until the robot is stopped
				StopTsk();
				break;
			case 7:
			    //shut down the robot
				ShutDwn();
				break;
		}
	}
}


//-------------------------StartHWIFun--------------------------
// Call function to bring robot up to speed using the StartUpClock
// Input: StateSema: starts the loop to verify state
// Output: none
void StartHWIFun(void){
	Semaphore_post(StateSema);

}


//-------------------------StartTsk--------------------------
// Bring robot up to speed
// Input: startDrive: indicates the current duty to apply to the motors
//        StateSema: starts the loop to verify state
// Output: none
void StartTsk(void){
		switch(startDrive){
			case 0:
				DriveForw(5,5);
				startDrive = 1;
				break;
			case 1:
				DriveForw(10,10);
				startDrive = 2;
				break;
			case 2:
				DriveForw(15,15);
				startDrive = 3;
				break;
			case 3:
				DriveForw(20,20);
				stateRob = 2;
				Semaphore_post(StateSema);  //wait 10 ms to change the motors
				break;
		}
}



//-------------------------StopHWIFun--------------------------
// Call function to bring robot to stop using the WTIMER3
// Input: StateSema: starts the loop to verify state
//            stateRob: indicates the current state to enter
// Output: none
void StopHWIFun(void){
	Semaphore_post(StateSema);
	stateRob = 6;
	TimerIntClear(WTIMER3_BASE, TIMER_BOTH);
	TimerEnable(WTIMER3_BASE, TIMER_A);
}



//-------------------------StopTsk--------------------------
// Bring robot to a stop
// Input: stopDrive: indicates the current speed to apply to the motors
//         StateSema: starts the loop to verify state
// Output: none
void StopTsk(void){
		const char stopflag[] ="Stop!!\n\r";

		switch(stopDrive){
			case 0:
				DriveForw(15,15);
				stopDrive = 1;
				break;
			case 1:
				DriveForw(10,10);
				stopDrive = 2;
				break;
			case 2:
				DriveForw(5,5);
				stopDrive = 3;
				break;
			case 3:
				DriveForw(0,0);
				TimerDisable(WTIMER3_BASE, TIMER_A);
				UART_write(uart,stopflag,sizeof(stopflag));
				Semaphore_post(StateSema);
				stateRob = 7;
				break;
		}

}

//-------------------------ShutDwn--------------------------
// End all tasks
// Input: none
// Output: none
void ShutDwn(void){

	endRace();

}
