/*
 * StateFunc.h
 *
 *  Created on: Nov 29, 2014
 *      Author: Chi-lun
 */

#ifndef STATEFUNC_H_
#define STATEFUNC_H_
#include "Global_v_and_headers.h"




/*
 * StateFunc.c
 *
 *  Created on: Nov 26, 2014
 *      Author: Daniel
 */



//-------------------------InitState--------------------------
// Decides the current configuration in the obsticle course
// Input: none
// Output: none
void InitState(void);

//-------------------------StateDriveInit--------------------------
// Decides the current configuration in the obsticle course
// Input: none
// Output: none
void StateFun(void);


//-------------------------StateTsk--------------------------
// Decides the current configuration in the obsticle course
// Input: none
// Output: none
void StateTsk(void);


//-------------------------StartHWIFun--------------------------
// Call SWI function to bring robot up to speed
// Input: none
// Output: none
void StartHWIFun(void);



//-------------------------StartTsk--------------------------
// Bring robot up to speed
// Input: none
// Output: none
void StartTsk(void);



//-------------------------StopHWIFun--------------------------
// Call SWI function to bring robot to stop
// Input: none
// Output: none
void StopHWIFun(void);



//-------------------------StopTsk--------------------------
// Bring robot to a stop
// Input: none
// Output: none
void StopTsk(void);

//-------------------------ShutDwn--------------------------
// End all tasks
// Input: none
// Output: none
void ShutDwn(void);



#endif /* STATEFUNC_H_ */
