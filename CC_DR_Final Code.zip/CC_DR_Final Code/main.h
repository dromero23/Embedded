/*
 * main.h
 *
 *  Created on: Nov 29, 2014
 *      Author: Chi-lun
 */

#ifndef MAIN_H_
#define MAIN_H_
#include "Global_v_and_headers.h"

/*
 *  ======== main ========
 */
int main(void);




#endif /* MAIN_H_ */
